import NavbarLayout from "./components/navbar/NavbarLayout";
import "../css/App.css";
import Footer from "./components/footer";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { lazy, Suspense } from "react";
import LoadingAnimation from "./components/LoadingAnimation";
import NotAvailable from "./components/NotAvailable";

const ListOfContents = lazy(() => import("./page/ListOfContents"));
const PostPage = lazy(() => import("./page/PostPage"));
const AdminPage = lazy(() => import("./page/admin/Admin"));
const LoginPage = lazy(() => import("./page/auth/Login"));

function App() {
    return (
        <div className="App">
            <NavbarLayout />
            <Suspense fallback={LoadingAnimation()}>
                <Router>
                    <div className="content">
                        <Switch>
                            <Route path="/" exact component={ListOfContents} />
                            <Route
                                path="/post/:slug"
                                exact
                                component={PostPage}
                            />
                            <Route path="/admin">
                                <AdminPage />
                            </Route>
                            <Route path="/login">
                                <LoginPage />
                            </Route>
                            <Route path="*">
                                <NotAvailable
                                    text={"Oops, apa yang anda cari tidak ada"}
                                />
                            </Route>
                        </Switch>
                    </div>
                </Router>
            </Suspense>
            <Footer />
        </div>
    );
}

export default App;
