import React, { useEffect } from "react";
import APIv2UserService from "../../service/APIv2UserService";
import "../../../css/Login.css";
import {
    InputLabel,
    Input,
    Theme,
    createTheme,
    ThemeProvider,
    Button,
    TextField,
} from "@material-ui/core";

const formTheme: Theme = createTheme({
    overrides: {
        MuiInputLabel: {
            root: {
                color: "var(--main-font-color)",
                marginBottom: "0.5em",
            },
        },
        MuiInputBase: {
            input: {
                color: "var(--main-font-color)",
            },
        },
    },
});

function getCookie(cname: string) {
    let name = cname + "=";
    let decodedCookie = decodeURIComponent(document.cookie);
    let ca = decodedCookie.split(";");
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == " ") {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}

const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const email = (document.getElementById("email") as HTMLInputElement).value;
    const password = (document.getElementById("password") as HTMLInputElement)
        .value;
    const credentials = { email, password };
    try {
        await fetch("/sanctum/csrf-cookie");
        const csrf = getCookie("XSRF-TOKEN");
        const response = await fetch("/api/login", {
            method: "POST",
            body: JSON.stringify(credentials),
            headers: {
                "X-XSRF-TOKEN": csrf,
                "Content-Type": "application/json",
            },
        });
        const json = await response.json();
        if (response.status != 200) return;
        localStorage.setItem("token", json.token);
        window.open("/", "_self");
    } catch (error) {
        console.error(error);
    }
};

const Login = () => {
    useEffect(() => {
        (async () => {
            const authenticatedUser =
                await new APIv2UserService().getAuthenticatedUser();
            if (authenticatedUser) window.open("/", "_self");
        })();
    }, []);

    return (
        <div
            style={{
                color: "white",
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                margin: "auto",
            }}
        >
            <h3>Login</h3>
            <form
                style={{
                    display: "flex",
                    flexDirection: "column",
                }}
                onSubmit={handleLogin}
            >
                <ThemeProvider theme={formTheme}>
                    <TextField
                        id="email"
                        label="E-mail"
                        name={"email"}
                        required
                        style={{ marginTop: "1em" }}
                    />
                    <TextField
                        id="password"
                        label="Password"
                        name={"password"}
                        type={"password"}
                        style={{ marginTop: "1em" }}
                        required
                    />
                    <Button
                        color="primary"
                        type="submit"
                        variant="contained"
                        style={{ marginTop: "1em" }}
                    >
                        Log in
                    </Button>
                </ThemeProvider>
            </form>
        </div>
    );
};

export default Login;
