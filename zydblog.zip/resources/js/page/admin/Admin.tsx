import React, { useEffect, useState } from "react";
import User from "../../model/User";
import APIv2UserService from "../../service/APIv2UserService";

const Admin = () => {
    const noUser = new User("", "", "");
    const [user, setUser] = useState(() => noUser);

    useEffect(() => {
        (async () => {
            const authenticatedUser =
                await new APIv2UserService().getAuthenticatedUser();
            if (authenticatedUser) setUser(authenticatedUser);
            window.open("/login", "_self");
            console.log(authenticatedUser);
        })();
    }, []);

    return <div></div>;
};

export default Admin;
