/// <reference types="react-scripts" />
declare module "raw-html-react";

declare module "*.webp" {
    export default "" as string;
}
